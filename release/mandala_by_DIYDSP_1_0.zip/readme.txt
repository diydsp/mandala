Mandala by DIYDSP
With music "Shortcut" by Stephen Paul Taylor
SID-tracked by DIYDSP

To run:
LOAD"L2",8
RUN

Takes about 30 seconds to load each segment: GFX, SONG, and DEMO.
sorry, still too lame to used a fastloader

Runs about 1 minute 51 seconds

