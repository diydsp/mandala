Mandala by DIYDSP
With music "Shortcut" by Stephen Paul Taylor
SID-tracked by DIYDSP

To run:
From WinVICE:   
Attach disk image ahope1.d64:   File->Attach Disk Image->Drive #8

Then from READY. prompt:
LOAD"L2",8
RUN

Takes about 30 seconds to load each segment: GFX, SONG, and DEMO.
sorry, still too lame to used a fastloader

Plays full song, but gfx repeat several times.
Please let play until end of song?
Runs about 1 minute 51 seconds

